Hi there!

Thank you for trying out Pokabalt. This game is based on Adam Saltsman's Canabalt.

Information:
One button infinite runner game. Push A to jump. The longer you press A, the more you can extend the jump, to a point.
Push C to pause the game.

Playing tip:
Use the crates to slow you down a bit every now and again, as the faster you run, the harder it is to aim and land without dying. Obviously, avoid the falling bombs!

The game saves the highscore on the real Pokitto.
To listen to the included music, ensure you have an SD card in your Pokitto and it has a folder called "music" and the song called �pokabalt.wav� in.

Credits:
Code, graphics, sfx, music - all by Jaco van der Walt.

If you like this game, please let us know! More of our games can be found at http://blackjet.co.uk - this game was made in January/February 2020.

Thanks for playing!

Regards,
Jaco